﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnValor_Click(object sender, EventArgs e)
        {
            float peso = float.Parse(txtPeso.Text);
            float valor;

            valor = peso * 34 / 1000;

            lblValor.Text = "o valor que você pagará é " + valor + " reais";
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
